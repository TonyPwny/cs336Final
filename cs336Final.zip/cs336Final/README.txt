# cs336Final
 
CS336
Professor Miranda
Group 4

Steve Nguyen (shn27) 		Project lead
				Set up Amazon RDS, EC2
				Code contribution and queries credited on JSP pages
Thomas Fiorilla (trf40)		Code contribution and queries credited on JSP pages
Nicolas Gundersen (neg62)	Code contribution and queries credited on JSP pages
Salman Saeed (sms786)		MySQL Database data input and maintenance
Anthony Tiongson (ast119)	Code contribution and queries credited on JSP pages


EC2 URL: incomplete
user:
pass:

RDS Hostname: steve2.ckgj9bgqpyor.us-east-2.rds.amazonaws.com:3306
user: admin
pass: password